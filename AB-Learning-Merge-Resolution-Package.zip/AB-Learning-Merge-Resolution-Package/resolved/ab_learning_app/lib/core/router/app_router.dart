import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/mock/models.dart';
import '../../data/mock/current_user.dart';
import '../di/providers.dart';
import '../network/api_client.dart';
import '../../features/auth/data/auth_repository.dart';
import '../../features/admin/presentation/admin_dashboard_screen.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/auth/presentation/onboarding_screen.dart';
import '../../features/auth/presentation/register_screen.dart';
import '../../features/corporate/presentation/corporate_dashboard_screen.dart';
import '../../features/corporate/presentation/corporate_workflows.dart';
import '../../features/course/presentation/course_detail_screen.dart';
import '../../features/course/presentation/curriculum_screen.dart';
import '../../features/course/presentation/payment_screen.dart';
import '../../features/course/presentation/video_player_screen.dart';
import '../../features/employer/presentation/employer_dashboard_screen.dart';
import '../../features/employer/presentation/employer_workflows.dart';
import '../../features/instructor/presentation/instructor_dashboard_screen.dart';
import '../../features/instructor/presentation/instructor_course_builder_screen.dart';
import '../../features/instructor/presentation/instructor_revenue_screen.dart';
import '../../features/instructor/presentation/my_courses_screen.dart';
import '../../features/instructor/presentation/instructor_workflows.dart';
import '../../features/admin/presentation/admin_workflows.dart';
import '../../features/quiz/presentation/quiz_result_screen.dart';
import '../../features/quiz/presentation/quiz_screen.dart';
import '../../features/auth/presentation/forgot_password_screen.dart';
import '../../features/auth/presentation/hifi_login_screen.dart';
import '../../features/auth/presentation/hifi_register_screen.dart';
import '../../features/auth/presentation/hifi_splash_screen.dart';
import '../../features/auth/presentation/interests_screen.dart';
import '../../features/auth/presentation/otp_screen.dart';
import '../../features/checkout/presentation/checkout_screen.dart';
import '../../features/community/presentation/community_screen.dart';
import '../../features/course/presentation/hifi_course_detail_screen.dart';
import '../../features/course/presentation/hifi_video_player_screen.dart';
import '../../features/explore/presentation/hifi_explore_screen.dart';
import '../../features/explore/presentation/search_screen.dart';
import '../../features/home/presentation/hifi_home_screen.dart';
import '../../features/learn/presentation/learn_screen.dart';
import '../../features/profile/presentation/certificates_screen.dart';
import '../../features/profile/presentation/edit_profile_screen.dart';
import '../../features/profile/presentation/help_center_screen.dart';
import '../../features/profile/presentation/portfolio_screen.dart';
import '../../features/profile/presentation/profile_screen.dart';
import '../../features/profile/presentation/settings_screen.dart';
import '../../features/profile/presentation/wallet_screen.dart';
import '../../features/tutor/presentation/ai_tutor_screen.dart';
import '../../features/ai_tutor/presentation/ai_tutor_screen.dart' as hifi_tutor;
import '../../features/course/presentation/certificate_screen.dart';
import '../../features/future/presentation/future_workspace_screen.dart';
import '../widgets/main_shell.dart';
import '../widgets/role_scaffold.dart';
import '../navigation/role_menus.dart';

final appRouterProvider = Provider<GoRouter>(
    (ref) => AppRouter(apiClient: ref.watch(apiClientProvider)).router);

class AppRouter {
  late final GoRouter router;

  AppRouter({ApiClient? apiClient}) {
    router = GoRouter(
      initialLocation: '/',
      redirect: (context, state) {
        final path = state.location;
        final requestedPrefix = _rolePrefixForPath(path);
        if (requestedPrefix == null) return null;
        final rolePrefix = _rolePrefixForRole(CurrentUser.role);
        return requestedPrefix == rolePrefix
            ? null
            : CurrentUser.homeRouteFor(CurrentUser.role);
      },
      routes: <GoRoute>[
        // --- Auth / onboarding (hi-fi UI) ---------------------------------
        GoRoute(
            path: '/', builder: (context, state) => const HifiSplashScreen()),
        GoRoute(
            path: '/onboarding',
            builder: (context, state) => const OnboardingScreen()),
        GoRoute(
            path: '/login',
            builder: (context, state) => const HifiLoginScreen()),
        GoRoute(
            path: '/register',
            builder: (context, state) => const HifiRegisterScreen()),
        GoRoute(
          path: '/otp',
          builder: (context, state) => OtpScreen(
            args: state.extra is OtpArgs ? state.extra as OtpArgs : null,
          ),
        ),
        GoRoute(
            path: '/interests',
            builder: (context, state) => const InterestsScreen()),
        GoRoute(
          path: '/forgot-password',
          builder: (context, state) => const ForgotPasswordScreen(),
        ),

        // --- Classic MVP screens (previous learner UI, kept reachable) -----
        GoRoute(
            path: '/classic/login',
            builder: (context, state) => LoginScreen(
                  authRepository: apiClient == null
                      ? null
                      : AuthRepository(apiClient: apiClient),
                )),
        GoRoute(
            path: '/classic/register',
            builder: (context, state) => RegisterScreen(
                  authRepository: apiClient == null
                      ? null
                      : AuthRepository(apiClient: apiClient),
                )),
        GoRoute(
            path: '/classic/home', builder: (context, state) => const MainShell()),
        GoRoute(
            path: '/classic/course/:id',
            builder: (context, state) =>
                CourseDetailScreen(courseId: state.pathParameters['id'] ?? '')),
        GoRoute(
            path: '/classic/player/:id',
            builder: (context, state) =>
                VideoPlayerScreen(lessonId: state.pathParameters['id'] ?? '')),
        GoRoute(
            path: '/my-learning',
            builder: (context, state) => const MainShell(initialIndex: 2)),

        // --- Learner (hi-fi screens) ----------------------------------------
        GoRoute(
            path: '/home', builder: (context, state) => const HifiHomeScreen()),
        GoRoute(
            path: '/explore',
            builder: (context, state) => const HifiExploreScreen()),
        GoRoute(
          path: '/search',
          builder: (context, state) =>
              SearchScreen(initialQuery: state.queryParameters['q'] ?? ''),
        ),
        GoRoute(
            path: '/learn', builder: (context, state) => const LearnScreen()),
        GoRoute(
            path: '/community',
            builder: (context, state) => const CommunityScreen()),
        GoRoute(
            path: '/profile',
            builder: (context, state) => const ProfileScreen()),
        GoRoute(
            path: '/profile/edit',
            builder: (context, state) => const EditProfileScreen()),
        GoRoute(
            path: '/wallet', builder: (context, state) => const WalletScreen()),
        GoRoute(
            path: '/certificates',
            builder: (context, state) => const CertificatesScreen()),
        GoRoute(
            path: '/portfolio',
            builder: (context, state) => const PortfolioScreen()),
        GoRoute(
            path: '/settings',
            builder: (context, state) => const SettingsScreen()),
        GoRoute(
            path: '/help',
            builder: (context, state) => const HelpCenterScreen()),

        GoRoute(
          path: '/course/:id',
          builder: (context, state) {
            final id = state.pathParameters['id'] ?? '';
            return HifiCourseDetailScreen(courseId: id);
          },
          routes: [
            GoRoute(
              path: 'curriculum',
              builder: (context, state) {
                final id = state.pathParameters['id'] ?? '';
                return CurriculumScreen(courseId: id);
              },
            ),
          ],
        ),
        // Real enrollment flow (mock repository / API). The test-mode
        // CheckoutScreen stays available at /checkout-demo/:id.
        GoRoute(
          path: '/checkout/:id',
          builder: (context, state) => PaymentScreen(
            courseId: state.pathParameters['id'] ?? '',
            courseTitle: state.extra as String?,
          ),
        ),
        GoRoute(
          path: '/checkout-demo/:id',
          builder: (context, state) =>
              CheckoutScreen(courseId: state.pathParameters['id'] ?? ''),
        ),
        GoRoute(
          path: '/player/:id',
          builder: (context, state) {
            final id = state.pathParameters['id'] ?? '';
            return HifiVideoPlayerScreen(lessonId: id);
          },
        ),
        GoRoute(
          path: '/quiz/:id',
          builder: (context, state) {
            final id = state.pathParameters['id'] ?? '';
            return QuizScreen(lessonId: id);
          },
        ),
        GoRoute(
          path: '/quiz-result',
          builder: (context, state) {
            final extra = state.extra as Map<String, dynamic>? ?? const {};
            return QuizResultScreen(
              result: extra['result'] as QuizAttemptResult,
              questions: extra['questions'] as List<QuizQuestion>,
              lessonId: extra['lessonId'] as String,
            );
          },
        ),
        GoRoute(
          path: '/tutor',
          builder: (context, state) => const hifi_tutor.HifiAiTutorScreen(),
        ),
        GoRoute(
          path: '/ai-tutor',
          builder: (context, state) => const AiTutorScreen(),
        ),
        GoRoute(
          path: '/certificate/:courseName',
          builder: (context, state) {
            final courseName = state.pathParameters['courseName'] ?? 'Course';
            return CertificateScreen(
              courseName: courseName.replaceAll('-', ' '),
            );
          },
        ),
        GoRoute(
          path: '/skill-assessment',
          builder: (context, state) =>
              const FutureWorkspaceScreen(area: 'assessment'),
        ),
        GoRoute(
          path: '/career-path',
          builder: (context, state) =>
              const FutureWorkspaceScreen(area: 'career'),
        ),
        GoRoute(
          path: '/live',
          builder: (context, state) => const FutureWorkspaceScreen(area: 'live'),
        ),
        GoRoute(
          path: '/jobs',
          builder: (context, state) => const FutureWorkspaceScreen(area: 'jobs'),
        ),


        // --- Instructor (Phase 2: RBAC + Role Shell) ------------------------
        GoRoute(
            path: '/instructor',
            builder: (context, state) => _rolePage(AppRole.instructor,
                '/instructor', 'Dashboard', const InstructorDashboardScreen())),
        GoRoute(
            path: '/instructor/courses',
            builder: (context, state) => _rolePage(AppRole.instructor,
                '/instructor/courses', 'My Courses', const MyCoursesScreen())),
        GoRoute(
            path: '/instructor/revenue',
            builder: (context, state) => _rolePage(
                AppRole.instructor,
                '/instructor/revenue',
                'Revenue',
                const InstructorRevenueScreen())),
        GoRoute(
          path: '/instructor/create-course',
          builder: (context, state) => _rolePage(
              AppRole.instructor,
              '/instructor/create-course',
              'Course Builder',
              const InstructorCreateCourseScreen()),
        ),
        GoRoute(
          path: '/instructor/course-builder/:id',
          builder: (context, state) {
            final courseId =
                int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
            return _rolePage(
                AppRole.instructor,
                state.location,
                'Course Builder',
                InstructorCourseBuilderScreen(courseId: courseId));
          },
        ),
        GoRoute(
          path: '/instructor/go-live',
          builder: (context, state) => _rolePage(AppRole.instructor,
              '/instructor/go-live', 'Go Live', const InstructorLiveScreen()),
        ),
        GoRoute(
            path: '/instructor/analytics',
            builder: (context, state) => _rolePage(
                AppRole.instructor,
                '/instructor/analytics',
                'Analytics',
                const InstructorAnalyticsScreen())),

        // --- Corporate (Phase 2: RBAC + Role Shell) -------------------------
        GoRoute(
            path: '/corporate',
            builder: (context, state) => _rolePage(AppRole.corpAdmin,
                '/corporate', 'Dashboard', const CorporateDashboardScreen())),
        GoRoute(
          path: '/corporate/employees',
          builder: (context, state) => _rolePage(
              AppRole.corpAdmin,
              '/corporate/employees',
              'Employees',
              const CorporateEmployeesScreen()),
        ),
        GoRoute(
          path: '/corporate/learning-paths',
          builder: (context, state) => _rolePage(
              AppRole.corpAdmin,
              '/corporate/learning-paths',
              'Learning Paths',
              const CorporateLearningPathsScreen()),
        ),
        GoRoute(
            path: '/corporate/reports',
            builder: (context, state) => _rolePage(
                AppRole.corpAdmin,
                '/corporate/reports',
                'Reports',
                const CorporateReportsScreen())),

        // --- Employer (Phase 2: RBAC + Role Shell) --------------------------
        GoRoute(
            path: '/employer',
            builder: (context, state) => _rolePage(AppRole.employer,
                '/employer', 'Dashboard', const EmployerDashboardScreen())),
        GoRoute(
            path: '/employer/jobs',
            builder: (context, state) => _rolePage(AppRole.employer,
                '/employer/jobs', 'Jobs', const EmployerJobsScreen())),
        GoRoute(
            path: '/employer/applications',
            builder: (context, state) => _rolePage(
                AppRole.employer,
                '/employer/applications',
                'Applications',
                const EmployerApplicationsScreen())),
        GoRoute(
            path: '/employer/talent',
            builder: (context, state) => _rolePage(
                AppRole.employer,
                '/employer/talent',
                'Talent Search',
                const EmployerTalentScreen())),

        // --- Admin (Phase 2: RBAC + Role Shell) -----------------------------
        GoRoute(
            path: '/admin',
            builder: (context, state) => _rolePage(AppRole.admin, '/admin',
                'Dashboard', const AdminDashboardScreen())),
        GoRoute(
          path: '/admin/users',
          builder: (context, state) => _rolePage(
              AppRole.admin, '/admin/users', 'Users', const AdminUsersScreen()),
        ),
        GoRoute(
          path: '/admin/moderation',
          builder: (context, state) => _rolePage(
              AppRole.admin,
              '/admin/moderation',
              'Course Moderation',
              const AdminModerationScreen()),
        ),
        GoRoute(
          path: '/admin/payments',
          builder: (context, state) => _rolePage(AppRole.admin,
              '/admin/payments', 'Payments', const AdminPaymentsScreen()),
        ),
        GoRoute(
          path: '/admin/settings',
          builder: (context, state) => _rolePage(AppRole.admin,
              '/admin/settings', 'Settings', const AdminSettingsScreen()),
        ),
      ],
    );
  }
}

String? _rolePrefixForPath(String path) {
  if (path == '/home' ||
      path.startsWith('/explore') ||
      path.startsWith('/my-learning') ||
      path.startsWith('/community') ||
      path.startsWith('/profile') ||
      path.startsWith('/course/') ||
      path.startsWith('/checkout/') ||
      path.startsWith('/player/') ||
      path.startsWith('/quiz') ||
      path.startsWith('/tutor') ||
      path.startsWith('/ai-tutor') ||
      path.startsWith('/certificate/') ||
      path.startsWith('/skill-assessment') ||
      path.startsWith('/career-path') ||
      path == '/live' ||
      path == '/jobs' ||
      path.startsWith('/learn') ||
      path.startsWith('/search') ||
      path.startsWith('/wallet') ||
      path.startsWith('/certificates') ||
      path.startsWith('/portfolio') ||
      path.startsWith('/settings') ||
      path.startsWith('/help') ||
      path == '/classic/home' ||
      path.startsWith('/classic/course/') ||
      path.startsWith('/classic/player/')) {
    return '/home';
  }
  for (final prefix in const [
    '/instructor',
    '/corporate',
    '/employer',
    '/admin'
  ]) {
    if (path == prefix || path.startsWith('$prefix/')) return prefix;
  }
  return null;
}

String _rolePrefixForRole(AppRole role) {
  switch (role) {
    case AppRole.learner:
      return '/home';
    case AppRole.instructor:
      return '/instructor';
    case AppRole.corpAdmin:
    case AppRole.corpManager:
      return '/corporate';
    case AppRole.employer:
      return '/employer';
    case AppRole.admin:
      return '/admin';
    case AppRole.guest:
      return '/home';
  }
}

Widget _rolePage(AppRole role, String route, String title, Widget child) {
  final actualRole =
      role == AppRole.corpAdmin && CurrentUser.role == AppRole.corpManager
          ? AppRole.corpManager
          : role;
  return RoleScaffold(
      role: actualRole, activeRoute: route, title: title, child: child);
}
